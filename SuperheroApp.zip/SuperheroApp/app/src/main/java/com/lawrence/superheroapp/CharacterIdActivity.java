package com.lawrence.superheroapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.lawrence.superheroapp.rest.RetrofitClient;
import com.lawrence.superheroapp.rest.model.Id;
import com.lawrence.superheroapp.rest.model.Image;
import com.lawrence.superheroapp.rest.network.GetService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CharacterIdActivity extends AppCompatActivity {

    private TextView mHeroName, mStrength, mSpeed, mPower;
    private ImageView mHeroImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_character_id);

        mHeroName = findViewById(R.id.superhero_name);
        mStrength = findViewById(R.id.superhero_strength);
        mSpeed = findViewById(R.id.superhero_speed);
        mPower = findViewById(R.id.superhero_power);
        mHeroImage = findViewById(R.id.superhero_image);

        Bundle extras = getIntent().getExtras();
        assert extras != null;
        String characterId = extras.getString("characterId");

        GetService service = RetrofitClient.buildService(GetService.class);
        Call<Id> call = service.getCharacterById(characterId);

        call.enqueue(new Callback<Id>() {
            @Override
            public void onResponse(Call<Id> call, Response<Id> response) {

                assert response.body() != null;
                if (response.body().getPowerstats() == null){
                    mSpeed.setText("No speed");
                    mPower.setText("No Power");
                }

                mHeroName.setText(String.format("Name: %s", response.body().getName()));
                mStrength.setText(String.format("Strength: %s", response.body().getPowerstats().getStrength()));
                mSpeed.setText(String.format("Speed: %s", response.body().getPowerstats().getSpeed()));
                mPower.setText(String.format("Power: %s", response.body().getPowerstats().getPower()));

            }

            @Override
            public void onFailure(Call<Id> call, Throwable t) {

            }
        });

        Call<Image> imageCall = service.getImage(characterId);
        imageCall.enqueue(new Callback<Image>() {
            @Override
            public void onResponse(Call<Image> call, Response<Image> response) {


            }

            @Override
            public void onFailure(Call<Image> call, Throwable t) {

            }
        });

    }
}