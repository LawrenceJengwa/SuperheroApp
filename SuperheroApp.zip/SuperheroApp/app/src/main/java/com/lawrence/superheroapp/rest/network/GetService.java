package com.lawrence.superheroapp.rest.network;

import com.lawrence.superheroapp.rest.model.Biography;
import com.lawrence.superheroapp.rest.model.Character;
import com.lawrence.superheroapp.rest.model.Id;
import com.lawrence.superheroapp.rest.model.Image;
import com.lawrence.superheroapp.rest.model.Login;
import com.lawrence.superheroapp.rest.model.Powerstats;
import com.lawrence.superheroapp.rest.model.Result;
import com.lawrence.superheroapp.rest.model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface GetService {

    @GET("access-token")
    Call<User>loginAccess();

    @GET("api/105581651029925/search/{name}")
    Call<Result>getResult(@Path("name") String name);

    @GET("api/105581651029925/{id}/biography")
    Call<List<Biography>> getBio(@Path("id") String characterId);

    @GET("api/105581651029925/{id}/powerstats")
    Call<List<Powerstats>> getPower(@Path("id") String characterId);

    @GET("api/105581651029925/{character-id}")
    Call<Id>getCharacterById(@Path("character-id") String id);

    @GET("api/105581651029925/{character-id}/image")
    Call<Image>getImage(@Path("character-id") String id);

}
