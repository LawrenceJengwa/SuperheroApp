package com.lawrence.superheroapp.rest.model;

public class Character {
   private String id;

    public Character(String id) {
        this.id = id;
    }
}
